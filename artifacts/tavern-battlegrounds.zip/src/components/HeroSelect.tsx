import { useGame } from "@/game/store";
import { HEROES, heroArt } from "@/game/heroes";

export function HeroSelect() {
  const pickHero = useGame((s) => s.pickHero);

  return (
    <div className="tavern-shell min-h-dvh px-4 py-8 sm:px-8">
      <div className="mx-auto max-w-5xl">
        <p className="text-center text-sm tracking-[0.2em] text-gold-2">选择英雄</p>
        <h2 className="font-display mt-2 text-center text-3xl font-bold">谁来坐镇你的酒馆</h2>
        <p className="mx-auto mt-2 max-w-md text-center text-sm text-muted">
          第一版英雄仅决定形象与名号，技能将在后续赛季加入。
        </p>
        <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
          {HEROES.map((h, i) => (
            <button
              key={h.id}
              type="button"
              onClick={() => pickHero(h.id)}
              className="group overflow-hidden rounded-xl border border-border bg-surface text-left shadow-panel transition-transform duration-150 ease-out hover:-translate-y-1 active:scale-[0.96]"
              style={{ animation: `pop-in 400ms ease backwards ${i * 40}ms` }}
            >
              <div className="aspect-[4/5] overflow-hidden">
                <img
                  src={heroArt(h.art)}
                  alt={h.name}
                  className="h-full w-full object-cover object-top transition-transform duration-300 group-hover:scale-105"
                />
              </div>
              <div className="px-3 py-2">
                <div className="font-display text-base font-semibold">{h.name}</div>
                <div className="text-xs text-muted">{h.title}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
