import { Play, BookOpen, Download } from "lucide-react";
import { useGame } from "@/game/store";

export function StartScreen() {
  const startSelect = useGame((s) => s.startSelect);
  const setHelp = useGame((s) => s.setHelp);

  return (
    <div className="tavern-shell relative flex min-h-dvh flex-col items-center justify-center px-5 py-10">
      <div className="absolute inset-0 bg-linear-to-b from-bg-deep/40 via-transparent to-bg-deep/80" />
      <div className="relative z-10 flex max-w-lg flex-col items-center text-center">
        <p className="text-sm font-medium tracking-[0.28em] text-gold-2">八人混战 · 自动对战</p>
        <h1 className="font-display mt-3 text-5xl font-bold tracking-tight text-fg sm:text-6xl">
          酒馆战棋
        </h1>
        <p className="mt-4 max-w-md text-pretty text-muted">
          招募随从、三连升金、升级酒馆。回合结束后战场将自动交锋，最后活下来的英雄加冕为王。
        </p>
        <div className="mt-8 flex w-full max-w-xs flex-col gap-3">
          <button type="button" className="action-btn primary h-12 text-base" onClick={startSelect}>
            <Play className="size-4" />
            开始对局
          </button>
          <button type="button" className="action-btn h-12" onClick={() => setHelp(true)}>
            <BookOpen className="size-4" />
            玩法说明
          </button>
          <a
            href="/tavern-battlegrounds.zip"
            download="tavern-battlegrounds.zip"
            className="action-btn h-12 no-underline"
          >
            <Download className="size-4" />
            下载源码
          </a>
        </div>
      </div>
    </div>
  );
}
