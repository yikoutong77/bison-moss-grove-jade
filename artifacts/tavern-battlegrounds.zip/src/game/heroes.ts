import type { HeroDef } from "./types";

export const HEROES: HeroDef[] = [
  { id: "jaina", name: "吉安娜", title: "肯瑞托的总法师", art: "HERO_08" },
  { id: "rexxar", name: "雷克萨", title: "兽人猎手", art: "HERO_05" },
  { id: "valeera", name: "瓦莉拉", title: "暗影收割者", art: "HERO_03" },
  { id: "uther", name: "乌瑟尔", title: "圣光的勇士", art: "HERO_04" },
  { id: "guldan", name: "古尔丹", title: "毁灭之手", art: "HERO_07" },
  { id: "malfurion", name: "玛法里奥", title: "塞纳里奥", art: "HERO_06" },
  { id: "thrall", name: "萨尔", title: "大地之环", art: "HERO_02" },
  { id: "garrosh", name: "加尔鲁什", title: "战歌酋长", art: "HERO_01" },
];

export const HERO_BY_ID: Record<string, HeroDef> = Object.fromEntries(
  HEROES.map((h) => [h.id, h]),
);

export function heroArt(art: string): string {
  return `/art/${art}.jpg`;
}
