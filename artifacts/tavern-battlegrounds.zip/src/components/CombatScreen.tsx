import { useEffect, useMemo, useRef, useState } from "react";
import { FastForward, Swords } from "lucide-react";
import { MinionCard } from "./MinionCard";
import { Hud } from "./Hud";
import { useGame } from "@/game/store";
import { HERO_BY_ID, heroArt } from "@/game/heroes";
import type { CombatEvent, CombatMinion } from "@/game/types";
import { sfx } from "@/game/audio";
import { cn } from "@/lib/utils";

function cloneBoard(b: CombatMinion[]): CombatMinion[] {
  return b.map((m) => ({ ...m, effects: m.effects.map((e) => ({ ...e })) }));
}

export function CombatScreen() {
  const combat = useGame((s) => s.combat);
  const events = useGame((s) => s.combatEvents);
  const phase = useGame((s) => s.phase);
  const speed = useGame((s) => s.speed);
  const setSpeed = useGame((s) => s.setSpeed);
  const skipCombat = useGame((s) => s.skipCombat);
  const continueFromResult = useGame((s) => s.continueFromResult);
  const players = useGame((s) => s.players);
  const youId = useGame((s) => s.youId);

  const [pBoard, setPBoard] = useState<CombatMinion[]>([]);
  const [eBoard, setEBoard] = useState<CombatMinion[]>([]);
  const [attacking, setAttacking] = useState<string | null>(null);
  const [hit, setHit] = useState<string | null>(null);
  const [banner, setBanner] = useState("战斗开始");
  const [floats, setFloats] = useState<Array<{ id: string; uid: string; text: string }>>([]);
  const idxRef = useRef(0);
  const boardsRef = useRef({ p: [] as CombatMinion[], e: [] as CombatMinion[] });

  const you = players.find((p) => p.id === youId);
  const opp = players.find((p) => p.id === combat?.opponentId);
  const youHero = you ? HERO_BY_ID[you.heroId] : undefined;
  const oppHero = opp ? HERO_BY_ID[opp.heroId] : undefined;

  const startKey = combat ? combat.playerStart.map((m) => m.uid).join() : "";

  useEffect(() => {
    if (!combat) return;
    const p = cloneBoard(combat.playerStart);
    const e = cloneBoard(combat.enemyStart);
    setPBoard(p);
    setEBoard(e);
    boardsRef.current = { p, e };
    idxRef.current = 0;
    setBanner("战斗开始");
    setAttacking(null);
    setHit(null);
  }, [startKey, combat]);

  const applyEvent = (ev: CombatEvent) => {
    const patch = (uid: string, fn: (m: CombatMinion) => CombatMinion | null, side?: "p" | "e") => {
      const run = (arr: CombatMinion[]) => {
        const next: CombatMinion[] = [];
        for (const m of arr) {
          if (m.uid !== uid) next.push(m);
          else {
            const n = fn(m);
            if (n) next.push(n);
          }
        }
        return next;
      };
      if (side !== "e") {
        const p = run(boardsRef.current.p);
        boardsRef.current.p = p;
        setPBoard(p);
      }
      if (side !== "p") {
        const e = run(boardsRef.current.e);
        boardsRef.current.e = e;
        setEBoard(e);
      }
    };

    switch (ev.type) {
      case "announce":
        setBanner(ev.text);
        break;
      case "attack":
        setAttacking(ev.attackerUid);
        setHit(ev.targetUid);
        sfx.hit();
        break;
      case "damage":
        patch(ev.uid, (m) => ({
          ...m,
          hp: ev.hpAfter,
          divineShield: ev.shieldPop ? false : m.divineShield,
        }));
        setFloats((f) => [
          ...f,
          {
            id: `${ev.uid}-${ev.at}`,
            uid: ev.uid,
            text: ev.shieldPop ? "圣盾" : `-${ev.amount}`,
          },
        ]);
        break;
      case "buff":
        patch(ev.uid, (m) => ({ ...m, atk: m.atk + ev.atk, hp: m.hp + ev.hp, maxHp: m.maxHp + ev.hp }));
        break;
      case "summon": {
        const board = ev.owner === "player" ? boardsRef.current.p.slice() : boardsRef.current.e.slice();
        board.splice(Math.min(ev.index, board.length), 0, { ...ev.minion });
        if (ev.owner === "player") {
          boardsRef.current.p = board;
          setPBoard(board);
        } else {
          boardsRef.current.e = board;
          setEBoard(board);
        }
        break;
      }
      case "death":
        sfx.death();
        patch(ev.uid, (m) => ({ ...m, dead: true, hp: 0 }));
        window.setTimeout(() => {
          const still = [...boardsRef.current.p, ...boardsRef.current.e].find(
            (m) => m.uid === ev.uid && m.dead,
          );
          if (still) patch(ev.uid, () => null);
        }, 320);
        break;
      case "reborn":
        patch(ev.uid, (m) => ({ ...m, hp: ev.hp, maxHp: ev.hp, reborn: false, dead: false }));
        break;
      case "end":
        setAttacking(null);
        setHit(null);
        if (ev.winner === "player") setBanner(ev.damage ? `胜利 · 造成 ${ev.damage} 点伤害` : "胜利");
        else if (ev.winner === "enemy") setBanner(`战败 · 受到 ${ev.damage} 点伤害`);
        else setBanner("平局");
        break;
    }
  };

  useEffect(() => {
    if (phase !== "combat" || !events.length) return;
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    const tick = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      acc += dt * speed;
      const interval = 0.32;
      while (acc >= interval) {
        acc -= interval;
        const i = idxRef.current;
        const ev = events[i];
        if (!ev) {
          useGame.getState().skipCombat();
          return;
        }
        applyEvent(ev);
        idxRef.current = i + 1;
        if (ev.type === "end") {
          useGame.getState().skipCombat();
          return;
        }
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, events, speed, startKey]);

  const floatByUid = useMemo(() => {
    const m = new Map<string, string>();
    for (const f of floats) m.set(f.uid, f.text);
    return m;
  }, [floats]);

  if (!combat || !you) return null;

  const renderRow = (board: CombatMinion[], side: "player" | "enemy") => (
    <div className="flex min-h-28 flex-wrap items-end justify-center gap-1.5 sm:gap-2">
      {board.map((m) => (
        <div key={m.uid} className="relative">
          <MinionCard
            inst={m}
            size="sm"
            attacking={attacking === m.uid}
            hit={hit === m.uid}
            lunge={side === "player" ? "up" : "down"}
          />
          {floatByUid.get(m.uid) && (
            <span className="pointer-events-none absolute left-1/2 top-2 z-10 -translate-x-1/2 animate-[floatnum_700ms_ease_forwards] text-sm font-bold text-hp-fg">
              {floatByUid.get(m.uid)}
            </span>
          )}
        </div>
      ))}
      {board.length === 0 && <p className="py-6 text-sm text-muted">战场空空</p>}
    </div>
  );

  return (
    <div className="tavern-shell flex min-h-dvh flex-col">
      <Hud />
      <div className="flex flex-1 flex-col gap-3 px-3 py-3 sm:px-8">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {oppHero && (
              <img src={heroArt(oppHero.art)} alt="" className="size-10 rounded-full object-cover object-top" />
            )}
            <div>
              <div className="font-display font-semibold">{opp?.name ?? "对手"}</div>
              <div className="text-xs text-muted">生命 {opp?.hp} · 酒馆 {opp?.tavernTier}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {([1, 2, 4] as const).map((sp) => (
              <button
                key={sp}
                type="button"
                className={cn("action-btn px-3", speed === sp && "primary")}
                onClick={() => setSpeed(sp)}
              >
                {sp}x
              </button>
            ))}
            <button type="button" className="action-btn" onClick={skipCombat}>
              <FastForward className="size-4" />
              跳过
            </button>
          </div>
        </div>

        <div className="panel rounded-xl p-3 sm:p-5">
          {renderRow(eBoard, "enemy")}
          <div className="my-3 flex items-center justify-center gap-2 text-gold-2">
            <Swords className="size-4" />
            <span className="font-display text-sm sm:text-base">{banner}</span>
          </div>
          {renderRow(pBoard, "player")}
        </div>

        <div className="mt-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            {youHero && (
              <img src={heroArt(youHero.art)} alt="" className="size-10 rounded-full object-cover object-top" />
            )}
            <div className="font-display font-semibold">{you.name}</div>
          </div>
        </div>
      </div>

      {phase === "result" && (
        <div className="fixed inset-0 z-20 grid place-items-center bg-bg-deep/50 p-4">
          <div className="panel w-full max-w-md rounded-2xl p-6 text-center">
            <h3 className="font-display text-2xl font-bold">
              {combat.winner === "player" ? "胜利" : combat.winner === "enemy" ? "战败" : "势均力敌"}
            </h3>
            <p className="mt-2 text-muted">
              {combat.winner === "tie"
                ? "双方同归于尽，无人受伤。"
                : combat.winner === "player"
                  ? `对手将受到 ${combat.damage} 点伤害。`
                  : `你受到 ${combat.damage} 点伤害。`}
            </p>
            <button type="button" className="action-btn primary mt-5 w-full" onClick={continueFromResult}>
              回到酒馆
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
