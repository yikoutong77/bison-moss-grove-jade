import { create } from "zustand";
import type { CombatEvent, CombatResult, MinionInst, Phase, PlayerState } from "./types";
import { simulateCombat } from "./combat";
import { aiPlayTurn } from "./ai";
import {
  addDiscovered,
  buyMinion,
  createPool,
  finishTurnBoards,
  freezeOne,
  freezeShop,
  initLobby,
  moveMinion,
  pairPlayers,
  pickDiscoverOptions,
  refreshShop,
  sellMinion,
  startTurn,
  upgradeTavern,
  type Pool,
} from "./engine";
import { createRng, type Rng } from "./rng";
import { HERO_BY_ID } from "./heroes";
import { sfx, unlockAudio, setMuted as setAudioMuted } from "./audio";

export type CombatSpeed = 1 | 2 | 4;

interface GameState {
  phase: Phase;
  turn: number;
  players: PlayerState[];
  youId: string;
  selectedShop: string | null;
  selectedBoard: string | null;
  combat: CombatResult | null;
  combatCursor: number;
  combatEvents: CombatEvent[];
  discover: MinionInst[];
  toast: string | null;
  muted: boolean;
  speed: CombatSpeed;
  nextPlace: number;
  lastOpponent: string | null;
  help: boolean;
  seed: number;
}

interface GameActions {
  startSelect: () => void;
  pickHero: (heroId: string) => void;
  buy: (uid: string) => void;
  sell: (uid: string) => void;
  refresh: () => void;
  freezeAll: () => void;
  freezeSlot: (uid: string) => void;
  upgrade: () => void;
  move: (uid: string, index: number) => void;
  selectShop: (uid: string | null) => void;
  selectBoard: (uid: string | null) => void;
  endTurn: () => void;
  skipCombat: () => void;
  continueFromResult: () => void;
  pickDiscover: (defId: string) => void;
  setMuted: (v: boolean) => void;
  setSpeed: (s: CombatSpeed) => void;
  setHelp: (v: boolean) => void;
  setToast: (t: string | null) => void;
  setCombatCursor: (n: number) => void;
  you: () => PlayerState | undefined;
}

let rng: Rng = createRng(Date.now());
let pool: Pool = createPool();

function withYou(players: PlayerState[], youId: string, fn: (p: PlayerState) => PlayerState): PlayerState[] {
  return players.map((p) => (p.id === youId ? fn(p) : p));
}

export const useGame = create<GameState & GameActions>((set, get) => ({
  phase: "menu",
  turn: 1,
  players: [],
  youId: "you",
  selectedShop: null,
  selectedBoard: null,
  combat: null,
  combatCursor: 0,
  combatEvents: [],
  discover: [],
  toast: null,
  muted: false,
  speed: 1,
  nextPlace: 8,
  lastOpponent: null,
  help: false,
  seed: 0,

  you: () => get().players.find((p) => p.id === get().youId),

  startSelect: () => {
    unlockAudio();
    sfx.click();
    set({ phase: "hero-select" });
  },

  pickHero: (heroId) => {
    unlockAudio();
    sfx.buy();
    const seed = (Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0;
    rng = createRng(seed);
    pool = createPool();
    const players = initLobby(heroId, rng);
    const turn = 1;
    const rolled = players.map((p) => startTurn(p, turn, pool, rng));
    const afterAi = rolled.map((p) => (p.isHuman ? p : aiPlayTurn(p, pool, rng)));
    set({
      phase: "tavern",
      turn,
      players: afterAi,
      youId: "you",
      selectedShop: null,
      selectedBoard: null,
      combat: null,
      discover: [],
      nextPlace: 8,
      lastOpponent: null,
      seed,
      toast: `${HERO_BY_ID[heroId]?.name ?? "英雄"} 进入酒馆`,
    });
  },

  selectShop: (uid) => set({ selectedShop: uid, selectedBoard: null }),
  selectBoard: (uid) => set({ selectedBoard: uid, selectedShop: null }),
  setToast: (t) => set({ toast: t }),
  setHelp: (v) => set({ help: v }),
  setSpeed: (s) => set({ speed: s }),
  setCombatCursor: (n) => set({ combatCursor: n }),
  setMuted: (v) => {
    set({ muted: v });
    setAudioMuted(v);
  },

  buy: (uid) => {
    const { players, youId, phase } = get();
    if (phase !== "tavern") return;
    const you = players.find((p) => p.id === youId);
    if (!you) return;
    const res = buyMinion(you, uid, rng);
    if (res.player === you) {
      if (you.gold < 3) set({ toast: "金币不足" });
      else if (you.board.length >= 7) set({ toast: "战场已满，先卖掉一只随从" });
      return;
    }
    sfx.buy();
    if (res.triple) {
      sfx.triple();
      const opts = pickDiscoverOptions(res.triple.sourceTier, rng);
      set({
        players: withYou(players, youId, () => res.player),
        selectedShop: null,
        phase: "discover",
        discover: opts,
        toast: `${res.triple.golden.golden ? "金色合成！" : "三连！"}`,
      });
      return;
    }
    set({
      players: withYou(players, youId, () => res.player),
      selectedShop: null,
    });
  },

  sell: (uid) => {
    const { players, youId, phase } = get();
    if (phase !== "tavern") return;
    const you = players.find((p) => p.id === youId);
    if (!you) return;
    sfx.sell();
    set({
      players: withYou(players, youId, (p) => sellMinion(p, uid, pool)),
      selectedBoard: null,
    });
  },

  refresh: () => {
    const { players, youId, phase } = get();
    if (phase !== "tavern") return;
    const you = players.find((p) => p.id === youId);
    if (!you || you.gold < 1) {
      set({ toast: "金币不足" });
      return;
    }
    sfx.refresh();
    set({
      players: withYou(players, youId, (p) => refreshShop(p, pool, rng)),
      selectedShop: null,
    });
  },

  freezeAll: () => {
    const { phase } = get();
    if (phase !== "tavern") return;
    sfx.freeze();
    set({ players: withYou(get().players, get().youId, freezeShop) });
  },

  freezeSlot: (uid) => {
    if (get().phase !== "tavern") return;
    sfx.freeze();
    set({ players: withYou(get().players, get().youId, (p) => freezeOne(p, uid)) });
  },

  upgrade: () => {
    const { players, youId, phase } = get();
    if (phase !== "tavern") return;
    const you = players.find((p) => p.id === youId);
    if (!you) return;
    if (you.tavernTier >= 6) {
      set({ toast: "酒馆已满级" });
      return;
    }
    if (you.gold < you.upgradeCost) {
      set({ toast: "金币不足，无法升级" });
      return;
    }
    sfx.upgrade();
    set({
      players: withYou(players, youId, upgradeTavern),
      toast: `酒馆升至 ${you.tavernTier + 1} 级`,
    });
  },

  move: (uid, index) => {
    if (get().phase !== "tavern") return;
    set({
      players: withYou(get().players, get().youId, (p) => moveMinion(p, uid, index)),
      selectedBoard: null,
    });
  },

  pickDiscover: (defId) => {
    const { players, youId } = get();
    sfx.coin();
    set({
      players: withYou(players, youId, (p) => addDiscovered(p, defId, rng)),
      phase: "tavern",
      discover: [],
    });
  },

  endTurn: () => {
    const st = get();
    if (st.phase !== "tavern") return;
    sfx.click();
    let players = st.players.map((p) => (p.alive ? finishTurnBoards(p, rng) : p));
    const alive = players.filter((p) => p.alive);
    const pairs = pairPlayers(
      alive.map((p) => p.id),
      rng,
      st.lastOpponent ?? undefined,
    );
    const youPair = pairs.find((x) => x.a === st.youId || x.b === st.youId);
    if (!youPair) {
      set({ phase: "gameover", players });
      return;
    }
    const oppId = youPair.a === st.youId ? youPair.b : youPair.a;
    const you = players.find((p) => p.id === st.youId)!;
    const opp = players.find((p) => p.id === oppId)!;
    const result = simulateCombat(you.board, opp.board, you.tavernTier, opp.tavernTier, rng);
    result.opponentId = oppId;
    result.ghost = Boolean(youPair.ghost);

    // Resolve other pairings silently
    let nextPlace = st.nextPlace;
    for (const pair of pairs) {
      if (pair.a === st.youId || pair.b === st.youId) continue;
      const a = players.find((p) => p.id === pair.a);
      const b = players.find((p) => p.id === pair.b);
      if (!a || !b) continue;
      const r = simulateCombat(a.board, b.board, a.tavernTier, b.tavernTier, rng);
      if (r.winner === "player") {
        const hp = b.hp - r.damage;
        players = players.map((p) =>
          p.id === b.id
            ? hp <= 0
              ? { ...p, hp: 0, alive: false, placement: nextPlace-- }
              : { ...p, hp }
            : p,
        );
      } else if (r.winner === "enemy") {
        const hp = a.hp - r.damage;
        players = players.map((p) =>
          p.id === a.id
            ? hp <= 0
              ? { ...p, hp: 0, alive: false, placement: nextPlace-- }
              : { ...p, hp }
            : p,
        );
      }
    }

    set({
      phase: "combat",
      players,
      combat: result,
      combatEvents: result.events,
      combatCursor: 0,
      lastOpponent: oppId,
      nextPlace,
      selectedShop: null,
      selectedBoard: null,
    });
  },

  skipCombat: () => {
    const { combat, phase } = get();
    if (phase !== "combat" || !combat) return;
    set({ combatCursor: combat.events.length - 1, phase: "result" });
  },

  continueFromResult: () => {
    const st = get();
    const combat = st.combat;
    if (!combat) return;
    let players = st.players;
    let nextPlace = st.nextPlace;
    const you = players.find((p) => p.id === st.youId)!;
    const opp = players.find((p) => p.id === combat.opponentId);

    if (combat.winner === "enemy") {
      sfx.lose();
      const hp = you.hp - combat.damage;
      players = players.map((p) =>
        p.id === you.id
          ? hp <= 0
            ? { ...p, hp: 0, alive: false, placement: nextPlace-- }
            : { ...p, hp }
          : p,
      );
    } else if (combat.winner === "player" && opp && opp.alive && !combat.ghost) {
      sfx.win();
      const hp = opp.hp - combat.damage;
      players = players.map((p) =>
        p.id === opp.id
          ? hp <= 0
            ? { ...p, hp: 0, alive: false, placement: nextPlace-- }
            : { ...p, hp }
          : p,
      );
    } else if (combat.winner === "tie") {
      sfx.click();
    } else if (combat.winner === "player") {
      sfx.win();
    }

    const living = players.filter((p) => p.alive);
    const youNow = players.find((p) => p.id === st.youId)!;
    if (!youNow.alive || living.length <= 1) {
      if (living.length === 1) {
        players = players.map((p) =>
          p.id === living[0]!.id && p.placement == null ? { ...p, placement: 1 } : p,
        );
      }
      set({ phase: "gameover", players, nextPlace, combat: null });
      return;
    }

    const turn = st.turn + 1;
    players = players.map((p) => (p.alive ? startTurn(p, turn, pool, rng) : p));
    players = players.map((p) => (p.alive && !p.isHuman ? aiPlayTurn(p, pool, rng) : p));
    set({
      phase: "tavern",
      turn,
      players,
      nextPlace,
      combat: null,
      combatEvents: [],
      combatCursor: 0,
      toast: `第 ${turn} 回合`,
    });
  },
}));
