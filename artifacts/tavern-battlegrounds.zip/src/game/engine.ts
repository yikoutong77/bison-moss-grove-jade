import type { MinionInst, PlayerState, Pairing } from "./types";
import {
  applyBattlecry,
  applyEndOfTurn,
  applyOnSummonBuffs,
  brannExtra,
  discoverPool,
} from "./combat";
import {
  BUY_COST,
  BY_TIER,
  COLLECTIBLE,
  COPIES_PER_TIER,
  MAX_BOARD,
  MAX_GOLD,
  REFRESH_COST,
  SELL_REWARD,
  SHOP_SIZE,
  START_HP,
  UPGRADE_BASE,
  defOf,
  makeInst,
} from "./minions";
import { HEROES } from "./heroes";
import type { Rng } from "./rng";
import { shuffle, uid } from "./rng";

export type Pool = Record<string, number>;

export function createPool(): Pool {
  const pool: Pool = {};
  for (const m of COLLECTIBLE) {
    pool[m.id] = COPIES_PER_TIER[m.tier] ?? 10;
  }
  return pool;
}

export function takeFromPool(pool: Pool, id: string): boolean {
  if ((pool[id] ?? 0) <= 0) return false;
  pool[id] = (pool[id] ?? 0) - 1;
  return true;
}

export function returnToPool(pool: Pool, m: MinionInst) {
  if (m.golden) return;
  const d = defOf(m.defId);
  if (d.token) return;
  pool[m.defId] = (pool[m.defId] ?? 0) + 1;
}

export function goldForTurn(turn: number): number {
  return Math.min(MAX_GOLD, turn + 2);
}

export function makePlayer(
  id: string,
  heroId: string,
  name: string,
  isHuman: boolean,
): PlayerState {
  return {
    id,
    name,
    heroId,
    hp: START_HP,
    tavernTier: 1,
    gold: goldForTurn(1),
    upgradeCost: UPGRADE_BASE[1] ?? 5,
    board: [],
    shop: [],
    frozen: false,
    isHuman,
    alive: true,
    placement: null,
    triples: 0,
  };
}

export function initLobby(humanHeroId: string, rng: Rng): PlayerState[] {
  const humanHero = HEROES.find((h) => h.id === humanHeroId) ?? HEROES[0]!;
  const rest = shuffle(
    HEROES.filter((h) => h.id !== humanHero.id),
    rng,
  );
  const players: PlayerState[] = [
    makePlayer("you", humanHero.id, humanHero.name, true),
  ];
  for (let i = 0; i < 7; i++) {
    const h = rest[i]!;
    players.push(makePlayer(`ai-${i}`, h.id, h.name, false));
  }
  return players;
}

export function rollShop(player: PlayerState, pool: Pool, rng: Rng): MinionInst[] {
  const size = SHOP_SIZE[player.tavernTier] ?? 3;
  const kept = player.frozen ? player.shop.filter((m) => m.frozen) : [];
  const need = Math.max(0, size - kept.length);
  const available: string[] = [];
  for (let t = 1; t <= player.tavernTier; t++) {
    for (const d of BY_TIER[t] ?? []) {
      const copies = pool[d.id] ?? 0;
      for (let i = 0; i < copies; i++) available.push(d.id);
    }
  }
  const picked: MinionInst[] = [];
  const bag = shuffle(available, rng);
  for (const id of bag) {
    if (picked.length >= need) break;
    if (takeFromPool(pool, id)) {
      picked.push(makeInst(id, false));
    }
  }
  return [...kept.map((m) => ({ ...m, frozen: false })), ...picked];
}

export function refreshShop(player: PlayerState, pool: Pool, rng: Rng): PlayerState {
  if (player.gold < REFRESH_COST) return player;
  for (const m of player.shop) {
    if (!m.frozen) returnToPool(pool, m);
  }
  const next = { ...player, gold: player.gold - REFRESH_COST, frozen: false };
  next.shop = rollShop({ ...next, frozen: false, shop: player.shop.filter((m) => m.frozen) }, pool, rng);
  return next;
}

export function freezeShop(player: PlayerState): PlayerState {
  const anyUnfrozen = player.shop.some((m) => !m.frozen);
  return {
    ...player,
    frozen: anyUnfrozen,
    shop: player.shop.map((m) => ({ ...m, frozen: anyUnfrozen })),
  };
}

export function freezeOne(player: PlayerState, uid: string): PlayerState {
  return {
    ...player,
    shop: player.shop.map((m) => (m.uid === uid ? { ...m, frozen: !m.frozen } : m)),
    frozen: player.shop.some((m) => (m.uid === uid ? !m.frozen : m.frozen)),
  };
}

export function upgradeTavern(player: PlayerState): PlayerState {
  if (player.tavernTier >= 6) return player;
  if (player.gold < player.upgradeCost) return player;
  const tier = player.tavernTier + 1;
  return {
    ...player,
    gold: player.gold - player.upgradeCost,
    tavernTier: tier,
    upgradeCost: UPGRADE_BASE[tier] ?? 0,
  };
}

export function startTurn(player: PlayerState, turn: number, pool: Pool, rng: Rng): PlayerState {
  const gold = goldForTurn(turn);
  const upgradeCost =
    player.tavernTier >= 6 ? 0 : Math.max(0, player.upgradeCost - (turn === 1 ? 0 : 1));
  let next: PlayerState = { ...player, gold, upgradeCost };
  const kept = next.frozen ? next.shop.filter((m) => m.frozen) : [];
  if (!next.frozen) {
    for (const m of next.shop) returnToPool(pool, m);
  } else {
    for (const m of next.shop) if (!m.frozen) returnToPool(pool, m);
  }
  next = { ...next, shop: kept, frozen: kept.length > 0 };
  next.shop = rollShop(next, pool, rng);
  return next;
}

export interface BuyResult {
  player: PlayerState;
  triple?: { golden: MinionInst; sourceTier: number };
}

export function buyMinion(
  player: PlayerState,
  shopUid: string,
  rng: Rng,
): BuyResult {
  if (player.gold < BUY_COST) return { player };
  if (player.board.length >= MAX_BOARD) return { player };
  const shopMinion = player.shop.find((m) => m.uid === shopUid);
  if (!shopMinion) return { player };

  let board = [...player.board, { ...shopMinion, frozen: false }];
  board = applyOnSummonBuffs(board, shopMinion);
  const extra = brannExtra(player.board);
  board = applyBattlecry(board, shopMinion, board.length - 1, rng, extra);

  const shop = player.shop.filter((m) => m.uid !== shopUid);
  let next: PlayerState = {
    ...player,
    gold: player.gold - BUY_COST,
    board,
    shop,
  };

  const fused = tryTriple(next);
  return fused;
}

export function tryTriple(player: PlayerState): BuyResult {
  const counts = new Map<string, MinionInst[]>();
  for (const m of player.board) {
    if (m.golden) continue;
    const d = defOf(m.defId);
    if (d.token) continue;
    const arr = counts.get(m.defId) ?? [];
    arr.push(m);
    counts.set(m.defId, arr);
  }
  for (const m of player.shop) {
    if (m.golden) continue;
    const d = defOf(m.defId);
    if (d.token) continue;
    const arr = counts.get(m.defId) ?? [];
    arr.push(m);
    counts.set(m.defId, arr);
  }
  for (const [defId, copies] of counts) {
    if (copies.length < 3) continue;
    const used = copies.slice(0, 3);
    const usedUids = new Set(used.map((m) => m.uid));
    const d = defOf(defId);
    const extraAtk = used.reduce((s, m) => s + (m.atk - d.atk), 0);
    const extraHp = used.reduce((s, m) => s + (m.hp - d.hp), 0);
    const golden = makeInst(defId, true);
    golden.atk += extraAtk;
    golden.hp += extraHp;
    golden.maxHp = golden.hp;
    const kw = new Set<MinionInst["keywords"][number]>();
    for (const m of used) for (const k of m.keywords) kw.add(k);
    golden.keywords = [...kw];

    let board = player.board.filter((m) => !usedUids.has(m.uid));
    const shop = player.shop.filter((m) => !usedUids.has(m.uid));
    if (board.length < MAX_BOARD) board = [...board, golden];
    else {
      shop.push(golden);
    }
    return {
      player: { ...player, board, shop, triples: player.triples + 1 },
      triple: { golden, sourceTier: d.tier },
    };
  }
  return { player };
}

export function sellMinion(player: PlayerState, boardUid: string, pool: Pool): PlayerState {
  const m = player.board.find((x) => x.uid === boardUid);
  if (!m) return player;
  returnToPool(pool, m);
  return {
    ...player,
    gold: Math.min(MAX_GOLD, player.gold + SELL_REWARD),
    board: player.board.filter((x) => x.uid !== boardUid),
  };
}

export function moveMinion(player: PlayerState, fromUid: string, toIndex: number): PlayerState {
  const from = player.board.findIndex((m) => m.uid === fromUid);
  if (from < 0) return player;
  const board = player.board.slice();
  const [item] = board.splice(from, 1);
  if (!item) return player;
  const idx = Math.max(0, Math.min(toIndex, board.length));
  board.splice(idx, 0, item);
  return { ...player, board };
}

export function addDiscovered(player: PlayerState, defId: string, rng: Rng): PlayerState {
  if (player.board.length >= MAX_BOARD) {
    if (player.shop.length < (SHOP_SIZE[player.tavernTier] ?? 6)) {
      return { ...player, shop: [...player.shop, makeInst(defId, false)] };
    }
    return player;
  }
  const inst = makeInst(defId, false);
  let board = [...player.board, inst];
  board = applyOnSummonBuffs(board, inst);
  board = applyBattlecry(board, inst, board.length - 1, rng, brannExtra(player.board));
  const fused = tryTriple({ ...player, board });
  return fused.player;
}

export function pickDiscoverOptions(tier: number, rng: Rng): MinionInst[] {
  const pool = discoverPool(Math.min(6, tier + 1));
  return shuffle(pool, rng).slice(0, 3);
}

export function pairPlayers(aliveIds: string[], rng: Rng, lastGhost?: string): Pairing[] {
  const ids = shuffle(aliveIds, rng);
  const pairs: Pairing[] = [];
  if (ids.length % 2 === 1) {
    const leftover = ids.pop()!;
    const ghost = lastGhost && lastGhost !== leftover ? lastGhost : ids[0] ?? leftover;
    pairs.push({ a: leftover, b: ghost, ghost: true });
  }
  for (let i = 0; i < ids.length; i += 2) {
    pairs.push({ a: ids[i]!, b: ids[i + 1]! });
  }
  return pairs;
}

export function applyFightDamage(
  players: PlayerState[],
  id: string,
  lost: boolean,
  damage: number,
  nextPlace: number,
): { players: PlayerState[]; nextPlace: number } {
  const next = players.map((p) => {
    if (p.id !== id) return p;
    if (!lost) return p;
    const hp = p.hp - damage;
    if (hp <= 0) {
      return { ...p, hp: 0, alive: false, placement: nextPlace };
    }
    return { ...p, hp };
  });
  const died = next.some((p, i) => !p.alive && players[i]?.alive);
  return { players: next, nextPlace: died ? nextPlace - 1 : nextPlace };
}

export function finishTurnBoards(player: PlayerState, rng: Rng): PlayerState {
  return { ...player, board: applyEndOfTurn(player.board, rng) };
}

export function recountAlive(players: PlayerState[]): PlayerState[] {
  const living = players.filter((p) => p.alive);
  if (living.length === 1) {
    return players.map((p) =>
      p.id === living[0]!.id ? { ...p, placement: 1 } : p,
    );
  }
  return players;
}

export function newUid(): string {
  return uid("m");
}
