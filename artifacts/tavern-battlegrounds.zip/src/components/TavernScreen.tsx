import { RefreshCw, Snowflake, ArrowUpCircle, Flag, Coins } from "lucide-react";
import { Hud } from "./Hud";
import { LobbyStrip } from "./LobbyStrip";
import { MinionCard } from "./MinionCard";
import { useGame } from "@/game/store";
import { BUY_COST, MAX_BOARD } from "@/game/minions";
import { cn } from "@/lib/utils";

export function TavernScreen() {
  const you = useGame((s) => s.players.find((p) => p.id === s.youId));
  const selectedShop = useGame((s) => s.selectedShop);
  const selectedBoard = useGame((s) => s.selectedBoard);
  const buy = useGame((s) => s.buy);
  const sell = useGame((s) => s.sell);
  const refresh = useGame((s) => s.refresh);
  const freezeAll = useGame((s) => s.freezeAll);
  const freezeSlot = useGame((s) => s.freezeSlot);
  const upgrade = useGame((s) => s.upgrade);
  const endTurn = useGame((s) => s.endTurn);
  const selectShop = useGame((s) => s.selectShop);
  const selectBoard = useGame((s) => s.selectBoard);
  const move = useGame((s) => s.move);
  const toast = useGame((s) => s.toast);
  const phase = useGame((s) => s.phase);
  const discover = useGame((s) => s.discover);
  const pickDiscover = useGame((s) => s.pickDiscover);

  if (!you) return null;
  const frozen = you.shop.some((m) => m.frozen);

  return (
    <div className="tavern-shell flex min-h-dvh flex-col">
      <Hud />
      <div className="flex min-h-0 flex-1 flex-col sm:flex-row">
        <div className="border-b border-border sm:hidden">
          <LobbyStrip />
        </div>
        <div className="flex min-w-0 flex-1 flex-col">
          <section className="px-3 pt-3 sm:px-5">
            <div className="mb-2 flex items-baseline justify-between">
              <h2 className="font-display text-lg font-semibold">鲍勃的酒馆</h2>
              <span className="text-xs text-muted">点击随从购买 · {BUY_COST} 金币</span>
            </div>
            <div className="panel flex gap-2 overflow-x-auto rounded-xl p-3">
              {you.shop.length === 0 && (
                <p className="py-8 text-sm text-muted">酒馆空空如也，试着刷新一下。</p>
              )}
              {you.shop.map((m) => (
                <MinionCard
                  key={m.uid}
                  inst={m}
                  size="lg"
                  selected={selectedShop === m.uid}
                  showFreeze
                  onFreeze={() => freezeSlot(m.uid)}
                  onClick={() => {
                    if (you.gold >= BUY_COST && you.board.length < MAX_BOARD) buy(m.uid);
                    else selectShop(m.uid);
                  }}
                />
              ))}
            </div>
          </section>

          <section className="flex-1 px-3 py-3 sm:px-5">
            <div className="mb-2 flex items-baseline justify-between">
              <h2 className="font-display text-lg font-semibold">你的战场</h2>
              <span className="text-xs text-muted">
                {you.board.length}/{MAX_BOARD} · 先手顺序从左到右
              </span>
            </div>
            <div className="panel flex min-h-32 items-end gap-2 overflow-x-auto rounded-xl p-3">
              {Array.from({ length: MAX_BOARD }).map((_, i) => {
                const m = you.board[i];
                return (
                  <div
                    key={m?.uid ?? `slot-${i}`}
                    className="slot grid place-items-center"
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      const uid = e.dataTransfer.getData("uid");
                      if (uid) move(uid, i);
                    }}
                  >
                    {m ? (
                      <div
                        draggable
                        onDragStart={(e) => e.dataTransfer.setData("uid", m.uid)}
                      >
                        <MinionCard
                          inst={m}
                          size="md"
                          selected={selectedBoard === m.uid}
                          onClick={() => {
                            if (selectedBoard && selectedBoard !== m.uid) {
                              const from = you.board.findIndex((x) => x.uid === selectedBoard);
                              if (from >= 0) move(selectedBoard, i);
                            } else {
                              selectBoard(selectedBoard === m.uid ? null : m.uid);
                            }
                          }}
                        />
                      </div>
                    ) : (
                      <span className="text-[0.65rem] text-faint">{i + 1}</span>
                    )}
                  </div>
                );
              })}
            </div>
            {selectedBoard && (
              <div className="mt-2 flex justify-end">
                <button type="button" className="action-btn" onClick={() => sell(selectedBoard)}>
                  <Coins className="size-4 text-gold" />
                  出售（+1 金币）
                </button>
              </div>
            )}
          </section>

          <nav className="sticky bottom-0 grid grid-cols-2 gap-2 border-t border-border bg-bg-deep/90 p-3 sm:grid-cols-4">
            <button
              type="button"
              className="action-btn"
              disabled={you.gold < 1}
              onClick={refresh}
            >
              <RefreshCw className="size-4" />
              刷新 · 1
            </button>
            <button type="button" className={cn("action-btn", frozen && "text-ice")} onClick={freezeAll}>
              <Snowflake className="size-4" />
              {frozen ? "解冻" : "冻结"}
            </button>
            <button
              type="button"
              className="action-btn gold"
              disabled={you.tavernTier >= 6 || you.gold < you.upgradeCost}
              onClick={upgrade}
            >
              <ArrowUpCircle className="size-4" />
              {you.tavernTier >= 6 ? "满级" : `升级 · ${you.upgradeCost}`}
            </button>
            <button type="button" className="action-btn primary" onClick={endTurn}>
              <Flag className="size-4" />
              结束回合
            </button>
          </nav>
        </div>
        <div className="hidden border-l border-border sm:block sm:w-52">
          <LobbyStrip />
        </div>
      </div>

      {toast && (
        <div className="pointer-events-none fixed bottom-24 left-1/2 z-20 -translate-x-1/2 rounded-full border border-border bg-surface-2 px-4 py-2 text-sm shadow-panel">
          {toast}
        </div>
      )}

      {phase === "discover" && (
        <div className="fixed inset-0 z-30 grid place-items-center bg-bg-deep/70 p-4">
          <div className="panel w-full max-w-xl rounded-2xl p-5">
            <h3 className="font-display text-center text-xl font-semibold">三连发现</h3>
            <p className="mt-1 text-center text-sm text-muted">从更高一级的随从中挑选一只加入战场。</p>
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              {discover.map((m) => (
                <MinionCard key={m.uid} inst={m} size="lg" onClick={() => pickDiscover(m.defId)} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
