import { X } from "lucide-react";
import { useGame } from "@/game/store";

export function HelpOverlay() {
  const help = useGame((s) => s.help);
  const setHelp = useGame((s) => s.setHelp);
  if (!help) return null;

  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-bg-deep/70 p-4">
      <div className="panel relative max-h-[85dvh] w-full max-w-lg overflow-y-auto rounded-2xl p-6">
        <button
          type="button"
          className="absolute right-3 top-3 grid size-10 place-items-center rounded-full border border-border"
          onClick={() => setHelp(false)}
          aria-label="关闭"
        >
          <X className="size-4" />
        </button>
        <h3 className="font-display text-2xl font-bold">玩法说明</h3>
        <div className="mt-4 space-y-3 text-sm leading-relaxed text-muted">
          <p>每回合获得金币（上限 10）。在酒馆购买随从、刷新、冻结、升级酒馆，然后结束回合进入自动战斗。</p>
          <p>购买花费 3 金币，刷新 1 金币，出售返还 1 金币。升级酒馆可解锁更高等级的随从。</p>
          <p>收集三只相同随从会合成金色随从：基础属性翻倍，并发现一只更高等级的随从。</p>
          <p>战斗时双方从左到右轮流攻击。嘲讽优先被打，圣盾抵消一次伤害，亡语与战吼会在对应时机触发。</p>
          <p>失败方扣除「对方酒馆等级 + 剩余随从星级」的生命。最后活着的玩家获胜。</p>
        </div>
        <button type="button" className="action-btn primary mt-6 w-full" onClick={() => setHelp(false)}>
          知道了
        </button>
      </div>
    </div>
  );
}
