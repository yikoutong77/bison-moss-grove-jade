import { useGame } from "@/game/store";
import { HERO_BY_ID, heroArt } from "@/game/heroes";
import { cn } from "@/lib/utils";

export function LobbyStrip() {
  const players = useGame((s) => s.players);
  const youId = useGame((s) => s.youId);
  const last = useGame((s) => s.lastOpponent);
  const ranked = [...players].sort((a, b) => {
    if (a.alive !== b.alive) return a.alive ? -1 : 1;
    return b.hp - a.hp;
  });

  return (
    <aside className="flex gap-2 overflow-x-auto px-3 py-2 sm:flex-col sm:overflow-visible sm:px-2">
      {ranked.map((p) => {
        const hero = HERO_BY_ID[p.heroId];
        return (
          <div
            key={p.id}
            className={cn(
              "flex min-w-28 items-center gap-2 rounded-lg border border-border bg-surface/80 px-2 py-1.5",
              !p.alive && "opacity-40",
              p.id === youId && "border-gold",
              p.id === last && "ring-1 ring-accent/70",
            )}
          >
            <img
              src={hero ? heroArt(hero.art) : ""}
              alt=""
              className="size-8 shrink-0 rounded-full object-cover object-top"
            />
            <div className="min-w-0">
              <div className="truncate text-xs font-semibold">{p.name}</div>
              <div className="flex gap-2 text-[0.65rem] text-muted">
                <span className="tabular text-hp">{p.alive ? p.hp : "出局"}</span>
                <span>T{p.tavernTier}</span>
                <span>{p.board.length} 随从</span>
              </div>
            </div>
          </div>
        );
      })}
    </aside>
  );
}
