import type { PlayerState } from "./types";
import {
  buyMinion,
  freezeShop,
  refreshShop,
  sellMinion,
  upgradeTavern,
  type Pool,
} from "./engine";
import { BUY_COST, MAX_BOARD, REFRESH_COST, defOf, minionValue } from "./minions";
import type { Rng } from "./rng";

function boardValue(p: PlayerState): number {
  return p.board.reduce((s, m) => s + minionValue(m), 0);
}

function wantsTriple(p: PlayerState, defId: string): boolean {
  const n = p.board.filter((m) => m.defId === defId && !m.golden).length;
  return n >= 2;
}

export function aiPlayTurn(player: PlayerState, pool: Pool, rng: Rng): PlayerState {
  let p = player;
  let guard = 24;
  while (guard-- > 0) {
    const shopBuyable = p.shop
      .map((m) => ({ m, v: minionValue(m) + (wantsTriple(p, m.defId) ? 40 : 0) }))
      .sort((a, b) => b.v - a.v);

    const canBuy = p.gold >= BUY_COST && shopBuyable.length > 0;
    const best = shopBuyable[0];

    const shouldUpgrade =
      p.tavernTier < 6 &&
      p.gold >= p.upgradeCost &&
      (p.board.length >= Math.min(4, p.tavernTier + 1) || p.upgradeCost <= 4) &&
      (p.gold - p.upgradeCost >= BUY_COST || p.board.length >= 3);

    if (shouldUpgrade && rng.chance(p.tavernTier <= 2 ? 0.7 : 0.55)) {
      p = upgradeTavern(p);
      continue;
    }

    if (canBuy && best) {
      if (p.board.length < MAX_BOARD) {
        const res = buyMinion(p, best.m.uid, rng);
        if (res.player !== p) {
          p = res.player;
          continue;
        }
      } else {
        const worst = [...p.board].sort((a, b) => minionValue(a) - minionValue(b))[0];
        if (worst && minionValue(best.m) > minionValue(worst) + 6) {
          p = sellMinion(p, worst.uid, pool);
          continue;
        }
      }
    }

    if (p.gold >= REFRESH_COST + (p.board.length < MAX_BOARD ? BUY_COST : 0) && p.gold >= 1) {
      const shopAvg =
        p.shop.reduce((s, m) => s + minionValue(m), 0) / Math.max(1, p.shop.length);
      if (shopAvg < 12 + p.tavernTier * 4 || p.board.length < 3) {
        const before = p.shop.map((m) => m.uid).join();
        p = refreshShop(p, pool, rng);
        if (p.shop.map((m) => m.uid).join() !== before) continue;
      }
    }

    if (p.tavernTier < 6 && p.gold >= p.upgradeCost) {
      p = upgradeTavern(p);
      continue;
    }

    break;
  }

  if (p.gold <= 1 && p.shop.some((m) => minionValue(m) >= 18 + p.tavernTier * 2)) {
    p = freezeShop(p);
  }

  // Light positioning: taunts toward the center-left, high attack first
  const board = [...p.board].sort((a, b) => {
    const ta = a.keywords.includes("taunt") ? 1 : 0;
    const tb = b.keywords.includes("taunt") ? 1 : 0;
    if (ta !== tb) return tb - ta;
    return b.atk - a.atk || defOf(b.defId).tier - defOf(a.defId).tier;
  });
  p = { ...p, board };

  void boardValue;
  return p;
}
