import type {
  CombatEvent,
  CombatMinion,
  CombatResult,
  Effect,
  Keyword,
  MinionInst,
  Side,
} from "./types";
import { BY_TIER, COLLECTIBLE, defOf, MINION_BY_ID, scaleN } from "./minions";
import type { Rng } from "./rng";
import { uid } from "./rng";

const MAX_STEPS = 90;
const DUR = {
  announce: 380,
  attack: 520,
  damage: 180,
  buff: 160,
  summon: 280,
  death: 280,
  reborn: 320,
  end: 500,
};

function hasKw(kws: Keyword[], k: Keyword): boolean {
  return kws.includes(k);
}

export function toCombatMinion(m: MinionInst, owner: Side): CombatMinion {
  const d = defOf(m.defId);
  return {
    uid: uid("c"),
    defId: m.defId,
    name: d.name,
    art: d.art,
    tribe: d.tribe,
    atk: m.atk,
    hp: m.hp,
    maxHp: m.maxHp,
    golden: m.golden,
    taunt: hasKw(m.keywords, "taunt"),
    divineShield: hasKw(m.keywords, "divineShield"),
    windfury: hasKw(m.keywords, "windfury"),
    poisonous: hasKw(m.keywords, "poisonous"),
    reborn: hasKw(m.keywords, "reborn"),
    cleave: hasKw(m.keywords, "cleave"),
    effects: d.effects.map((e) => ({ ...e })),
    owner,
    dead: false,
  };
}

function living(board: CombatMinion[]): CombatMinion[] {
  return board.filter((m) => !m.dead && m.hp > 0);
}

export function simulateCombat(
  playerBoard: MinionInst[],
  enemyBoard: MinionInst[],
  playerTier: number,
  enemyTier: number,
  rng: Rng,
): CombatResult {
  const playerStart = playerBoard.map((m) => toCombatMinion(m, "player"));
  const enemyStart = enemyBoard.map((m) => toCombatMinion(m, "enemy"));
  const sim = new CombatSim(
    playerStart.map((m) => ({ ...m, effects: m.effects.map((e) => ({ ...e })) })),
    enemyStart.map((m) => ({ ...m, effects: m.effects.map((e) => ({ ...e })) })),
    rng,
  );
  sim.startOfCombat();

  const pCount = living(sim.player).length;
  const eCount = living(sim.enemy).length;
  let attacker: Side =
    pCount > eCount ? "player" : eCount > pCount ? "enemy" : rng.chance(0.5) ? "player" : "enemy";

  sim.log({
    type: "announce",
    at: 0,
    text: attacker === "player" ? "你先手攻击" : "对手先手攻击",
  });

  const nextIdx: Record<Side, number> = { player: 0, enemy: 0 };
  let steps = 0;

  while (living(sim.player).length && living(sim.enemy).length && steps < MAX_STEPS) {
    steps++;
    const board = sim.board(attacker);
    const start = nextIdx[attacker];
    const atkMinion = sim.nextAttacker(board, start);
    if (!atkMinion) {
      attacker = attacker === "player" ? "enemy" : "player";
      continue;
    }
    const attacks = atkMinion.windfury ? 2 : 1;
    for (let a = 0; a < attacks; a++) {
      if (atkMinion.dead || atkMinion.hp <= 0) break;
      if (!living(sim.board(sim.opp(attacker))).length) break;
      sim.performAttack(atkMinion);
    }
    const after = sim.board(attacker);
    const idx = after.findIndex((m) => m.uid === atkMinion.uid);
    nextIdx[attacker] = idx === -1 ? start : idx + 1;
    attacker = attacker === "player" ? "enemy" : "player";
  }

  const pLeft = living(sim.player);
  const eLeft = living(sim.enemy);
  let winner: Side | "tie" = "tie";
  let damage = 0;
  if (pLeft.length && !eLeft.length) {
    winner = "player";
    damage = enemyTier + eLeft.length + pLeft.reduce((s, m) => s + defOf(m.defId).tier, 0);
    // remaining minion tiers of winner + winner tavern tier
    damage = playerTier + pLeft.reduce((s, m) => s + Math.max(1, defOf(m.defId).tier), 0);
  } else if (eLeft.length && !pLeft.length) {
    winner = "enemy";
    damage = enemyTier + eLeft.reduce((s, m) => s + Math.max(1, defOf(m.defId).tier), 0);
  }

  sim.log({
    type: "end",
    at: 0,
    winner,
    damage,
    playerLeft: pLeft.length,
    enemyLeft: eLeft.length,
  });

  return {
    events: sim.events,
    winner,
    damage,
    playerFinal: sim.player.filter((m) => !m.dead),
    enemyFinal: sim.enemy.filter((m) => !m.dead),
    opponentId: "",
    playerStart,
    enemyStart,
    ghost: false,
  };
}

class CombatSim {
  player: CombatMinion[];
  enemy: CombatMinion[];
  events: CombatEvent[] = [];
  time = 0;
  rng: Rng;
  summonDepth = 0;

  constructor(player: CombatMinion[], enemy: CombatMinion[], rng: Rng) {
    this.player = player;
    this.enemy = enemy;
    this.rng = rng;
  }

  log(e: CombatEvent) {
    const ev = { ...e, at: this.time } as CombatEvent;
    this.events.push(ev);
    this.time += DUR[e.type] ?? 200;
  }

  board(side: Side): CombatMinion[] {
    return side === "player" ? this.player : this.enemy;
  }

  setBoard(side: Side, b: CombatMinion[]) {
    if (side === "player") this.player = b;
    else this.enemy = b;
  }

  opp(side: Side): Side {
    return side === "player" ? "enemy" : "player";
  }

  nextAttacker(board: CombatMinion[], start: number): CombatMinion | null {
    const live = living(board);
    if (!live.length) return null;
    const n = board.length;
    for (let i = 0; i < n; i++) {
      const m = board[(start + i) % n];
      if (m && !m.dead && m.hp > 0 && m.atk > 0) return m;
    }
    for (const m of live) {
      if (m.atk > 0) return m;
    }
    return live[0] ?? null;
  }

  validTargets(side: Side): CombatMinion[] {
    const foes = living(this.board(this.opp(side)));
    const taunts = foes.filter((m) => m.taunt);
    return taunts.length ? taunts : foes;
  }

  startOfCombat() {
    for (const side of ["player", "enemy"] as Side[]) {
      const board = living(this.board(side));
      for (let i = 0; i < board.length; i++) {
        const m = board[i]!;
        for (const fx of m.effects) {
          if (fx.kind === "start_combat_aura_adjacent") {
            const full = living(this.board(side));
            const idx = full.findIndex((x) => x.uid === m.uid);
            for (const n of [idx - 1, idx + 1]) {
              const t = full[n];
              if (t) this.buff(t, scaleN(fx.atk, m.golden), 0);
            }
          }
          if (fx.kind === "start_combat_aura_tribe") {
            for (const t of living(this.board(side))) {
              if (t.uid === m.uid) continue;
              if (t.tribe === fx.tribe) {
                this.buff(t, scaleN(fx.atk, m.golden), scaleN(fx.hp, m.golden));
              }
            }
          }
        }
      }
    }
    for (const side of ["player", "enemy"] as Side[]) {
      for (const m of living(this.board(side))) {
        for (const fx of m.effects) {
          if (fx.kind === "start_combat_damage_random") {
            const foes = living(this.board(this.opp(side)));
            if (foes.length) {
              const t = this.rng.pick(foes);
              this.dealDamage(m, t, scaleN(fx.damage, m.golden), false);
            }
          }
        }
      }
      this.collectDeaths();
    }
  }

  performAttack(attacker: CombatMinion) {
    const targets = this.validTargets(attacker.owner);
    if (!targets.length) return;
    const target = this.rng.pick(targets);
    this.log({ type: "attack", at: 0, attackerUid: attacker.uid, targetUid: target.uid });

    const foes = living(this.board(this.opp(attacker.owner)));
    const tIdx = foes.findIndex((m) => m.uid === target.uid);
    const cleaveTargets: CombatMinion[] = [target];
    if (attacker.cleave) {
      if (tIdx > 0 && foes[tIdx - 1]) cleaveTargets.push(foes[tIdx - 1]!);
      if (tIdx < foes.length - 1 && foes[tIdx + 1]) cleaveTargets.push(foes[tIdx + 1]!);
    }

    for (const t of cleaveTargets) {
      this.dealDamage(attacker, t, attacker.atk, attacker.poisonous);
    }
    if (!target.dead && target.hp > 0 && target.atk > 0) {
      this.dealDamage(target, attacker, target.atk, target.poisonous);
    }

    this.collectDeaths();

    if (!attacker.dead && attacker.hp > 0) {
      for (const fx of attacker.effects) {
        if (fx.kind === "after_attack_buff_tribe") {
          for (const ally of living(this.board(attacker.owner))) {
            if (ally.tribe === fx.tribe) {
              this.buff(ally, scaleN(fx.atk, attacker.golden), scaleN(fx.hp, attacker.golden));
            }
          }
        }
      }
    }
  }

  dealDamage(source: CombatMinion, target: CombatMinion, amount: number, poisonous: boolean) {
    if (amount <= 0 || target.dead) return;
    if (target.divineShield) {
      target.divineShield = false;
      this.log({
        type: "damage",
        at: 0,
        uid: target.uid,
        amount: 0,
        shieldPop: true,
        hpAfter: target.hp,
      });
      return;
    }
    target.hp -= amount;
    if (poisonous) target.hp = 0;
    this.log({
      type: "damage",
      at: 0,
      uid: target.uid,
      amount,
      shieldPop: false,
      hpAfter: Math.max(0, target.hp),
    });

    if (target.hp > 0) {
      for (const fx of target.effects) {
        if (fx.kind === "on_damaged_summon_random_demon") {
          const demons = COLLECTIBLE.filter((d) => d.tribe === "demon" && d.tier <= 5);
          const pick = this.rng.pick(demons);
          this.summonToken(target.owner, pick.id, false, this.insertIndex(target), false);
        }
      }
    }
  }

  buff(t: CombatMinion, atk: number, hp: number) {
    t.atk += atk;
    t.hp += hp;
    t.maxHp += hp;
    this.log({ type: "buff", at: 0, uid: t.uid, atk, hp });
  }

  insertIndex(deadOrRef: CombatMinion): number {
    const board = this.board(deadOrRef.owner);
    const i = board.findIndex((m) => m.uid === deadOrRef.uid);
    return i === -1 ? board.length : i + 1;
  }

  baronCount(side: Side): number {
    let n = 0;
    for (const m of living(this.board(side))) {
      if (m.effects.some((e) => e.kind === "baron")) n += m.golden ? 2 : 1;
    }
    return n;
  }

  collectDeaths() {
    const dying: CombatMinion[] = [];
    for (const side of ["player", "enemy"] as Side[]) {
      for (const m of this.board(side)) {
        if (!m.dead && m.hp <= 0) dying.push(m);
      }
    }
    for (const m of dying) {
      if (m.dead) continue;
      m.dead = true;
      this.log({ type: "death", at: 0, uid: m.uid });
      const times = 1 + this.baronCount(m.owner);
      for (let i = 0; i < times; i++) this.runDeathrattles(m);
      if (m.reborn) {
        m.dead = false;
        m.hp = 1;
        m.maxHp = 1;
        m.reborn = false;
        m.divineShield = hasKw(defOf(m.defId).keywords, "divineShield") && m.golden;
        this.log({ type: "reborn", at: 0, uid: m.uid, hp: 1 });
      }
    }
    for (const side of ["player", "enemy"] as Side[]) {
      this.setBoard(
        side,
        this.board(side).filter((m) => !m.dead),
      );
    }
  }

  runDeathrattles(m: CombatMinion) {
    const side = m.owner;
    const insertAt = this.insertIndex(m);
    for (const fx of m.effects) {
      switch (fx.kind) {
        case "deathrattle_summon": {
          const count = scaleN(fx.count, m.golden);
          for (let i = 0; i < count; i++) {
            this.summonToken(side, fx.tokenId, m.golden, insertAt + i, true);
          }
          break;
        }
        case "deathrattle_summon_attack": {
          const summoned = this.summonToken(side, fx.tokenId, m.golden, insertAt, true);
          if (summoned) this.performAttack(summoned);
          break;
        }
        case "deathrattle_buff_all": {
          for (const t of living(this.board(side))) {
            if (fx.tribe && t.tribe !== fx.tribe) continue;
            this.buff(t, scaleN(fx.atk, m.golden), scaleN(fx.hp, m.golden));
          }
          break;
        }
        case "deathrattle_damage_random": {
          const foes = living(this.board(this.opp(side)));
          if (foes.length) {
            this.dealDamage(m, this.rng.pick(foes), scaleN(fx.damage, m.golden), false);
          }
          break;
        }
        case "deathrattle_damage_all": {
          const all = [...living(this.player), ...living(this.enemy)];
          for (const t of all) {
            this.dealDamage(m, t, scaleN(fx.damage, m.golden), false);
          }
          break;
        }
        case "deathrattle_divine_shield_tribe": {
          for (const t of living(this.board(side))) {
            if (t.tribe === fx.tribe) t.divineShield = true;
          }
          break;
        }
        case "deathrattle_summon_random_high": {
          const pool = COLLECTIBLE.filter((d) => d.tier >= 4);
          const pick = this.rng.pick(pool);
          this.summonToken(side, pick.id, false, insertAt, true);
          break;
        }
        default:
          break;
      }
    }
    this.collectDeaths();
  }

  summonToken(
    side: Side,
    defId: string,
    golden: boolean,
    index: number,
    triggerSummon: boolean,
  ): CombatMinion | null {
    const board = this.board(side);
    if (living(board).length >= 7) return null;
    const d = MINION_BY_ID[defId];
    if (!d) return null;
    const instLike: MinionInst = {
      uid: uid("c"),
      defId,
      atk: golden ? d.atk * 2 : d.atk,
      hp: golden ? d.hp * 2 : d.hp,
      maxHp: golden ? d.hp * 2 : d.hp,
      golden,
      keywords: [...d.keywords],
    };
    const cm = toCombatMinion(instLike, side);
    const insert = Math.max(0, Math.min(index, board.length));
    board.splice(insert, 0, cm);
    this.log({ type: "summon", at: 0, owner: side, minion: { ...cm }, index: insert });

    if (triggerSummon && this.summonDepth < 4) {
      this.summonDepth++;
      this.onSummoned(cm);
      this.summonDepth--;
    }
    return cm;
  }

  onSummoned(newbie: CombatMinion) {
    const board = living(this.board(newbie.owner));
    for (const m of board) {
      if (m.uid === newbie.uid) continue;
      for (const fx of m.effects) {
        if (fx.kind === "on_summon_buff" && newbie.tribe === fx.tribe) {
          this.buff(newbie, scaleN(fx.atk, m.golden), scaleN(fx.hp, m.golden));
        }
        if (fx.kind === "on_friendly_summon_token" && newbie.defId !== fx.tokenId) {
          this.summonToken(
            newbie.owner,
            fx.tokenId,
            m.golden,
            this.insertIndex(newbie),
            false,
          );
        }
      }
    }
  }
}

export function applyBattlecry(
  board: MinionInst[],
  played: MinionInst,
  playIndex: number,
  rng: Rng,
  extraTimes: number,
): MinionInst[] {
  const d = defOf(played.defId);
  const times = 1 + extraTimes;
  let next = board;
  for (let t = 0; t < times; t++) {
    for (const fx of d.effects) {
      next = runBattlecry(next, played, playIndex, fx, rng);
    }
  }
  return next;
}

function runBattlecry(
  board: MinionInst[],
  played: MinionInst,
  playIndex: number,
  fx: Effect,
  rng: Rng,
): MinionInst[] {
  const g = played.golden;
  switch (fx.kind) {
    case "battlecry_summon": {
      if (board.length >= 7) return board;
      const token = makeBoardToken(fx.tokenId, g);
      const copy = board.slice();
      copy.splice(Math.min(playIndex + 1, copy.length), 0, token);
      return applyOnSummonBuffs(copy, token).slice(0, 7);
    }
    case "battlecry_buff_tribe": {
      const cands = board.filter(
        (m) => m.uid !== played.uid && defOf(m.defId).tribe === fx.tribe,
      );
      if (!cands.length) {
        if (defOf(played.defId).tribe === fx.tribe) {
          return board.map((m) =>
            m.uid === played.uid ? buffInst(m, scaleN(fx.atk, g), scaleN(fx.hp, g)) : m,
          );
        }
        return board;
      }
      const t = rng.pick(cands);
      return board.map((m) =>
        m.uid === t.uid ? buffInst(m, scaleN(fx.atk, g), scaleN(fx.hp, g)) : m,
      );
    }
    case "battlecry_buff_others": {
      return board.map((m) => {
        if (m.uid === played.uid) return m;
        if (fx.tribe && defOf(m.defId).tribe !== fx.tribe) return m;
        return buffInst(m, scaleN(fx.atk, g), scaleN(fx.hp, g));
      });
    }
    case "battlecry_buff_adjacent": {
      return board.map((m, i) => {
        if (Math.abs(i - playIndex) === 1) {
          let n = buffInst(m, scaleN(fx.atk, g), scaleN(fx.hp, g));
          if (fx.taunt && !n.keywords.includes("taunt")) {
            n = { ...n, keywords: [...n.keywords, "taunt"] };
          }
          return n;
        }
        return m;
      });
    }
    case "battlecry_adapt_beasts": {
      return board.map((m) => {
        if (defOf(m.defId).tribe !== "beast") return m;
        let n = buffInst(m, scaleN(fx.atk, g), scaleN(fx.hp, g));
        if (!n.keywords.includes("divineShield")) {
          n = { ...n, keywords: [...n.keywords, "divineShield"] };
        }
        return n;
      });
    }
    default:
      return board;
  }
}

function makeBoardToken(defId: string, golden: boolean): MinionInst {
  const d = defOf(defId);
  const atk = golden ? d.atk * 2 : d.atk;
  const hp = golden ? d.hp * 2 : d.hp;
  return {
    uid: uid("m"),
    defId,
    atk,
    hp,
    maxHp: hp,
    golden,
    keywords: [...d.keywords],
  };
}

function buffInst(m: MinionInst, atk: number, hp: number): MinionInst {
  return { ...m, atk: m.atk + atk, hp: m.hp + hp, maxHp: m.maxHp + hp };
}

export function applyOnSummonBuffs(board: MinionInst[], newbie: MinionInst): MinionInst[] {
  let extraAtk = 0;
  let extraHp = 0;
  const dNew = defOf(newbie.defId);
  for (const m of board) {
    if (m.uid === newbie.uid) continue;
    const d = defOf(m.defId);
    for (const fx of d.effects) {
      if (fx.kind === "on_summon_buff" && dNew.tribe === fx.tribe) {
        extraAtk += scaleN(fx.atk, m.golden);
        extraHp += scaleN(fx.hp, m.golden);
      }
    }
  }
  if (!extraAtk && !extraHp) return board;
  return board.map((m) => (m.uid === newbie.uid ? buffInst(m, extraAtk, extraHp) : m));
}

export function applyEndOfTurn(board: MinionInst[], rng: Rng): MinionInst[] {
  let next = board.map((m) => ({ ...m, keywords: [...m.keywords] }));
  for (const m of board) {
    const d = defOf(m.defId);
    for (const fx of d.effects) {
      if (fx.kind === "end_turn_buff_self") {
        next = next.map((x) =>
          x.uid === m.uid ? buffInst(x, scaleN(fx.atk, m.golden), scaleN(fx.hp, m.golden)) : x,
        );
      }
      if (fx.kind === "end_turn_buff_random") {
        const others = next.filter((x) => x.uid !== m.uid);
        const t = others.length ? rng.pick(others) : next.find((x) => x.uid === m.uid);
        if (t) {
          next = next.map((x) =>
            x.uid === t.uid ? buffInst(x, scaleN(fx.atk, m.golden), scaleN(fx.hp, m.golden)) : x,
          );
        }
      }
    }
  }
  return next;
}

export function brannExtra(board: MinionInst[]): number {
  let n = 0;
  for (const m of board) {
    if (defOf(m.defId).effects.some((e) => e.kind === "brann")) n += m.golden ? 2 : 1;
  }
  return n;
}

export function discoverPool(tier: number): MinionInst[] {
  const t = Math.min(6, Math.max(1, tier));
  return (BY_TIER[t] ?? []).map((d) => ({
    uid: uid("d"),
    defId: d.id,
    atk: d.atk,
    hp: d.hp,
    maxHp: d.hp,
    golden: false,
    keywords: [...d.keywords],
  }));
}
