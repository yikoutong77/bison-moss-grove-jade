import { Coins, Heart, Layers, RotateCcw, Volume2, VolumeX, CircleHelp } from "lucide-react";
import { useGame } from "@/game/store";
import { HERO_BY_ID, heroArt } from "@/game/heroes";

export function Hud() {
  const turn = useGame((s) => s.turn);
  const you = useGame((s) => s.players.find((p) => p.id === s.youId));
  const muted = useGame((s) => s.muted);
  const setMuted = useGame((s) => s.setMuted);
  const setHelp = useGame((s) => s.setHelp);
  if (!you) return null;
  const hero = HERO_BY_ID[you.heroId];

  return (
    <header className="flex flex-wrap items-center gap-2 border-b border-border bg-bg-deep/70 px-3 py-2 backdrop-blur-sm sm:px-4">
      <div className="flex items-center gap-2">
        <img
          src={hero ? heroArt(hero.art) : ""}
          alt=""
          className="size-10 rounded-full border border-gold object-cover object-top"
        />
        <div>
          <div className="font-display text-sm font-semibold leading-tight">{you.name}</div>
          <div className="text-[0.7rem] text-muted">第 {turn} 回合</div>
        </div>
      </div>
      <div className="ml-auto flex flex-wrap items-center gap-1.5 sm:gap-2">
        <div className="hud-chip">
          <Heart className="size-4 text-hp" />
          <span className="tabular font-semibold">{you.hp}</span>
        </div>
        <div className="hud-chip">
          <Coins className="size-4 text-gold" />
          <span className="tabular font-semibold">{you.gold}</span>
        </div>
        <div className="hud-chip">
          <Layers className="size-4 text-gold-2" />
          <span className="tabular font-semibold">酒馆 {you.tavernTier}</span>
        </div>
        <button
          type="button"
          className="hud-chip"
          onClick={() => setMuted(!muted)}
          aria-label={muted ? "打开声音" : "静音"}
        >
          {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
        </button>
        <button type="button" className="hud-chip" onClick={() => setHelp(true)} aria-label="帮助">
          <CircleHelp className="size-4" />
        </button>
        <span className="hidden sm:inline-flex">
          <RotateCcw className="size-0" />
        </span>
      </div>
    </header>
  );
}
