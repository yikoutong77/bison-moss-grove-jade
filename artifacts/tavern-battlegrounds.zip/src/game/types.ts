export type Tribe =
  | "beast"
  | "murloc"
  | "mech"
  | "demon"
  | "dragon"
  | "pirate"
  | "neutral";

export type Keyword =
  | "taunt"
  | "divineShield"
  | "windfury"
  | "poisonous"
  | "reborn"
  | "cleave";

export type Effect =
  | { kind: "battlecry_summon"; tokenId: string }
  | { kind: "battlecry_buff_tribe"; tribe: Tribe; atk: number; hp: number }
  | { kind: "battlecry_buff_others"; tribe?: Tribe; atk: number; hp: number }
  | { kind: "battlecry_buff_adjacent"; atk: number; hp: number; taunt?: boolean }
  | { kind: "battlecry_adapt_beasts"; atk: number; hp: number }
  | { kind: "deathrattle_summon"; tokenId: string; count: number }
  | { kind: "deathrattle_summon_attack"; tokenId: string }
  | { kind: "deathrattle_buff_all"; atk: number; hp: number; tribe?: Tribe }
  | { kind: "deathrattle_damage_random"; damage: number }
  | { kind: "deathrattle_damage_all"; damage: number }
  | { kind: "deathrattle_divine_shield_tribe"; tribe: Tribe }
  | { kind: "deathrattle_summon_random_high" }
  | { kind: "end_turn_buff_self"; atk: number; hp: number }
  | { kind: "end_turn_buff_random"; atk: number; hp: number }
  | { kind: "start_combat_damage_random"; damage: number }
  | { kind: "start_combat_aura_adjacent"; atk: number }
  | { kind: "start_combat_aura_tribe"; tribe: Tribe; atk: number; hp: number }
  | { kind: "on_summon_buff"; tribe: Tribe; atk: number; hp: number }
  | { kind: "on_friendly_summon_token"; tokenId: string }
  | { kind: "on_damaged_summon_random_demon" }
  | { kind: "after_attack_buff_tribe"; tribe: Tribe; atk: number; hp: number }
  | { kind: "baron" }
  | { kind: "brann" };

export interface MinionDef {
  id: string;
  name: string;
  art: string;
  tier: 1 | 2 | 3 | 4 | 5 | 6;
  tribe: Tribe;
  atk: number;
  hp: number;
  keywords: Keyword[];
  effects: Effect[];
  text: string;
  token?: boolean;
}

export interface MinionInst {
  uid: string;
  defId: string;
  atk: number;
  hp: number;
  maxHp: number;
  golden: boolean;
  keywords: Keyword[];
  frozen?: boolean;
}

export interface HeroDef {
  id: string;
  name: string;
  title: string;
  art: string;
}

export interface PlayerState {
  id: string;
  name: string;
  heroId: string;
  hp: number;
  tavernTier: number;
  gold: number;
  upgradeCost: number;
  board: MinionInst[];
  shop: MinionInst[];
  frozen: boolean;
  isHuman: boolean;
  alive: boolean;
  placement: number | null;
  triples: number;
}

export type Phase =
  | "menu"
  | "hero-select"
  | "tavern"
  | "discover"
  | "combat"
  | "result"
  | "gameover";

export type Side = "player" | "enemy";

export interface CombatMinion {
  uid: string;
  defId: string;
  name: string;
  art: string;
  tribe: Tribe;
  atk: number;
  hp: number;
  maxHp: number;
  golden: boolean;
  taunt: boolean;
  divineShield: boolean;
  windfury: boolean;
  poisonous: boolean;
  reborn: boolean;
  cleave: boolean;
  effects: Effect[];
  owner: Side;
  dead: boolean;
}

export type CombatEvent =
  | { type: "announce"; at: number; text: string }
  | { type: "attack"; at: number; attackerUid: string; targetUid: string }
  | {
      type: "damage";
      at: number;
      uid: string;
      amount: number;
      shieldPop: boolean;
      hpAfter: number;
    }
  | { type: "buff"; at: number; uid: string; atk: number; hp: number }
  | { type: "summon"; at: number; owner: Side; minion: CombatMinion; index: number }
  | { type: "death"; at: number; uid: string }
  | { type: "reborn"; at: number; uid: string; hp: number }
  | {
      type: "end";
      at: number;
      winner: Side | "tie";
      damage: number;
      playerLeft: number;
      enemyLeft: number;
    };

export interface CombatResult {
  events: CombatEvent[];
  winner: Side | "tie";
  damage: number;
  playerFinal: CombatMinion[];
  enemyFinal: CombatMinion[];
  opponentId: string;
  playerStart: CombatMinion[];
  enemyStart: CombatMinion[];
  ghost: boolean;
}

export interface Pairing {
  a: string;
  b: string;
  ghost?: boolean;
}
